import os

CONFIG_ROOT_DIR = os.environ.get('CONFIG_ROOT_DIR', "~/.short_link/config")
